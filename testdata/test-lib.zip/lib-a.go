package liba

func HelloFromLibA() string {
    return "Hello from Library A!"
}
